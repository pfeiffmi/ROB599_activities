# Data Sender publisher in ROS2
#
# data_receiver.py
#
# Michael Pfeiffer
#
# Subscribe to data coming from the data publisher node

import rclpy
from rclpy.node import Node

from hw3_interfaces.msg import TestPacket
from std_msgs.msg import Float32

class Data_Receiver(Node):
    def __init__(self, log_data):
        # Initiallize the parent class
        super().__init__("data_receiver")

        # store the decision to log data or not
        self.log_data = log_data

        self.latency_calculations = [0]*10
        self.index = 0

        # Create publishers for the node
        self.publisher_raw_latency = self.create_publisher(Float32, "raw_latency", 10)
        self.publisher_mean_latency = self.create_publisher(Float32, "latency", 10)

        # Create a subscriber for the node
        self.subscriber = self.create_subscription(TestPacket, "data", self.callback, 10)

    def callback(self, msg):
        # Indicate that a message was received
        self.get_logger().info(f"Got: [{msg.send_time/1e9}] {msg.payload}")

        # compute the latency in ms by using the message's stored time
        current_time = self.get_clock().now().nanoseconds
        message_time = msg.send_time
        latency_time_ms = (current_time - message_time)/1e6

        # publish the raw latency reading
        raw_latency_msg = Float32()
        raw_latency_msg.data = latency_time_ms
        self.publisher_raw_latency.publish(raw_latency_msg)
        self.get_logger().info(f"Publishing Raw Latency (ms): {raw_latency_msg.data}")

        # calculate the running average of the last 10 latency readings
        self.latency_calculations[self.index] = latency_time_ms
        self.index = (self.index + 1)%10
        mean_latency_ms = sum(self.latency_calculations)/10

        # publish the mean latency reading
        mean_latency_msg = Float32()
        mean_latency_msg.data = mean_latency_ms
        self.publisher_mean_latency.publish(mean_latency_msg)
        self.get_logger().info(f"Publishing Mean Latency (ms): {mean_latency_msg.data}")


def main(args=None):
    # initiallize the ROS2 Client Library for Python
    rclpy.init(args=args)
    
    # Initiallize the data receiver
    data_receiver = Data_Receiver(log_data=False)

    # Give control of thread to ROS2
    rclpy.spin(data_receiver)

    # Clean shutdown
    rclpy.shutdown()
