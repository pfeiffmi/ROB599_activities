# Data Sender publisher in ROS2
#
# data_sender.py
#
# Michael Pfeiffer
#
# Publish data with a custom message interface

import rclpy
from rclpy.node import Node

from hw3_interfaces.msg import TestPacket
from hw3_interfaces.srv import SetStatus

class Data_Sender(Node):
    def __init__(self, data):
        # Initiallize the parent class
        super().__init__("data_sender")

        # store the data to send in each packet
        self.data = data

        # Create a publisher for the node
        self.publisher = self.create_publisher(TestPacket, "data", 10)
        
        # Create a service to 
        self.send_data_server = Send_Data(send_data=True)

        # Instantiate the timer at 10 Hz
        self.timer = self.create_timer(0.1, self.callback)

    def callback(self):
        # determine if messages should be published
        if(not self.send_data_server.send_data):
            return
        
        # Fill the message with the relevant data
        msg = TestPacket()
        msg.send_time = self.get_clock().now().nanoseconds
        msg.payload = self.data

        # publish the message
        self.publisher.publish(msg)
        # Log the published nmessage info
        self.get_logger().info(f'Published: [{msg.send_time/1e9}] {msg.payload}')


class Send_Data(Node):
    def __init__(self, send_data=True):
        # Initiallize the parent class
        super().__init__('send_data')

        # Store the variable for the server 
        self.send_data = send_data

        # define the service
        self.service = self.create_service(SetStatus, 'send', self.callback)

    def callback(self, request, response):
        # Log that a service request was received
        self.get_logger().info(f'Request - send_data set to {request.data}')

        # set the send_data variable to match the requested boolean
        self.send_data = request.data

        # Set the response data and send the response
        response.success = True
        return response


def main(args=None):
    # initiallize the ROS2 Client Library for Python
    rclpy.init(args=args)
    
    # Initiallize the data sender
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    data_sender = Data_Sender(data=data)

    # Give control of thread to ROS2
    rclpy.spin(data_sender)

    # Clean shutdown
    rclpy.shutdown()
